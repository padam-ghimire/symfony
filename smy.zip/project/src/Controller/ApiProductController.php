<?php

namespace App\Controller;

use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Product;
use Symfony\Component\HttpFoundation\Request;

class ApiProductController extends AbstractController
{
    private ProductRepository $productRepository;

    public function __construct(ProductRepository $productRepository)
    {
        $this->productRepository = $productRepository;
    }

    #[Route('/api/products', name: 'api_products', methods: ['GET'])]
    public function index(Request $request): JsonResponse
    {

        
        
        $this->denyAccessUnlessGranted('IS_AUTHENTICATED_FULLY');

        // Your logic to fetch products
        $products = $this->productRepository->findAll();

        // Transform products to a format suitable for response
        $formattedProducts = array_map(function (Product $product) {
            return $this->formatProduct($product);
        }, $products);

        return $this->json($formattedProducts);
    }

  
    private function formatProduct(Product $product): array
    {
        return [
            'id' => $product->getId(),
            'name' => $product->getName(),
        ];
    }
}
